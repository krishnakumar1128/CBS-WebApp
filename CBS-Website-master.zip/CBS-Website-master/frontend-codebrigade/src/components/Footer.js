import React from "react"


function Footer(){
return (
    <footer>
    <div className="container">
        <div className="row">
            <div className="col-lg-6 col-xs-12">
                <div className="left-text-content">
                    <p>Copyright &copy; 2021 .CBS </p>
                </div>
            </div>
        </div>
    </div>
</footer>
);
};

export default Footer;