const games = [
    {
      key: 1,
      title: "QWOP",
      image: "https://i.ytimg.com/vi/YbYOsE7JyXs/hqdefault.jpg",
      link :"http://www.foddy.net/Athletics.html",
      content:
        "QWOP is a legendary web game. The goal is simple: successfully run 100 meters. Except, doing that is anything but simple, as you have to manually control the thighs and calves of the runner. Don't be surprised if it takes you a while to get off the start line, but at least you'll have a laugh doing it."
    },
    {
      key: 2,
      title: "Entanglement",
      link:"http://entanglement.gopherwoodstudios.com/en-US-index.html",
      image : "https://lh3.googleusercontent.com/Bp4r4M27g0ErdoGWDb8gummolEev0kMej76GCQtTsPidTwDh8fdm0hYvjDOA4us83kDJrWjQiBf4ckqgKP_Tt4AVbQ=w640-h400-e365-rj-sc0x00ffffff",
      content:
        "How to keep a programmer in the shower forever. Show him the shampoo bottle instructions: Lather. Rinse. Repeat."
    },
    {
        key: 3,
        title: "Quick, Draw!",
        link:"http://quickdraw.withgoogle.com",
        image : "https://quickdraw.withgoogle.com/static/shareimg.png",
        content:
          "Quick, Draw! is not only a game, but also a way of training a neural network. You are presented with a word and then get a short amount of time to doodle it. "
      },
  
  ];
  
  export default games;
  