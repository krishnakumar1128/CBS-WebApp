const team = [
  {
    id: ".01",
    first_name: "Amit",
    last_name: "Kumar Singh",
    branch: "ECE",
    year: "3rd Year",
    image: "/assets/images/mem-amit.jpeg",
    facebook:
      "https://www.facebook.com/people/Amit-Kumar-Singh/100004330866832/",
    github: "https://github.com/amitsinghmnnit",
    linkedin: "https://www.linkedin.com/in/amit-kumar-singh-58b2061a0/",
  },
  {
    id: ".02",
    first_name: "Gaurav",
    last_name: "Kumar",
    branch: "ECE",
    year: "3rd Year",
    image: "/assets/images/mem-gaurav.png",
    facebook: "https://www.facebook.com/gauravk268",
    github: "https://github.com/gauravk268",
    linkedin: "https://www.linkedin.com/in/gauravk268/",
  },
  {
    id: ".03",
    first_name: "Mayank",
    last_name: "Sengar",
    branch: "ECE",
    year: "3rd Year",
    image: "/assets/images/mem-mayank.jpg",
    facebook: "https://www.facebook.com/mayank.sengar.54",
    github: "https://github.com/MayankSengar198",
    linkedin: "https://www.linkedin.com/in/mayank-sengar/",
  },
  {
    id: ".04",
    first_name: "Vinay",
    last_name: "Sharma",
    branch: "ECE",
    year: "3rd Year",
    image: "/assets/images/mem-vinay.jpeg",
    facebook: "https://www.facebook.com/profile.php?id=100006661875686",
    github: "https://github.com/VinaySharmaMnnit",
    linkedin: "https://www.linkedin.com/in/vinay-sharma-11a35a179/",
  },
];

export default team;
