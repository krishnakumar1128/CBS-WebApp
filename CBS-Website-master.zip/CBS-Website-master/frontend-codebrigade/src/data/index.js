import notes from "./notes";

export { notes };
